# zip2john 설치 및 사용법

- 암호가 걸린 ZIP 파일에서 John the Ripper 크래킹용 해시를 추출하는 유틸리티(zip2john 파일.zip > hash.txt)
- 침투 테스트에서 암호 걸린 ZIP 백업·아카이브를 확보해 내용을 확인해야 할 때, 추출한 해시를 john --wordlist=rockyou.txt로 바로 이어갈 때
- john 패키지 설치(apt install john), ZIP 파일에 실제 암호가 설정되어 있어야 함(암호 없는 ZIP은 unzip으로 바로 풀림), 워드리스트 준비

## 1. zip2john 이란?

- John the Ripper(암호 크래킹 도구)에서 ZIP 압축 파일 암호 해시를 추출하는 툴
- ZIP 파일 암호 크래킹 준비용

---

## 2. 설치 방법 (Ubuntu/Debian 기준)

```bash
sudo apt update
sudo apt install john
```

- `zip2john`은 `john` 패키지에 포함되어 있음
- 설치 후 바로 사용 가능

---

## 3. 사용법

### 기본 사용법

```bash
zip2john 파일명.zip > hash.txt
```

- ZIP 파일의 암호화 정보(해시)를 추출해 `hash.txt`에 저장
- 추출된 해시를 John the Ripper로 크래킹 가능이 가능해짐

---

### 예시

```bash
zip2john wordpress.old.zip > wordpress_hash.txt
john --wordlist=/usr/share/wordlists/rockyou.txt wordpress_hash.txt
```

- 먼저 `zip2john`으로 해시 추출
- 이후 `john`으로 단어 리스트(rockyou.txt) 기반 크래킹

---

## 4. 참고

- `zip2john`은 ZIP 파일에 암호가 걸렸을 때만 유용함
- 암호가 없으면 그냥 unzip으로 풀면 됨

---
