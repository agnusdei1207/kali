# ffuf를 통한 디렉토리 브루트포싱

- ffuf — FUZZ 자리에 워드리스트를 대입해 디렉토리·파일·파라미터·vhost(Host 헤더)를 브루트포스하는 웹 퍼저. -fs/-fc/-fl/-fw 필터로 노이즈를 제거한다.
- 웹서버 발견 직후 숨은 경로를 찾을 때, DNS 없이 Host 헤더 조작(-H "Host: FUZZ.대상")으로 서브도메인을 탐지할 때, 로그인 폼 POST 퍼징을 할 때.
- apt install ffuf와 SecLists 워드리스트 필요. HTTPS엔 -k, 기본 페이지 응답 크기(-fs)를 먼저 재서 제외하는 게 정석이며 스레드 -t는 10-50으로 조절한다.

```bash
sudo apt install fuff
```

## 기본 명령어 구조

```bash
ffuf -u http://HOST:PORT/FUZZ -w 워드리스트경로 [옵션]
```

## ffuf 사용 -> 대회용 -t 100 적절

ffuf -u http://10.10.178.114:8080/FUZZ -w /usr/share/wordlists/seclists/Dicovery/Web-Content/common.txt -fs 74

## port 명시할 경우 반드시 싱크 맞추기

ffuf -u http://10.10.178.114:80 -H "Host:FUZZ.10.10.178.114:80" -w /usr/share/seclists/Discovery/DNS/namelist.txt -fs 178 -t 100

## 주요 옵션 설명

### `-H` 옵션 (HTTP 헤더 지정) + subdomain

```bash
ffuf -u http://planning.htb -H "Host:FUZZ.planning.htb" -w /usr/share/seclists/Discovery/DNS/namelist.txt -fs 178 -t 50 -mc 200,302 -fc 304 > ffuf_result.txt

# X-Forwarded-For
ffuf -u http://192.168.86.200/FUZZ -H "X-Forwarded-For: 10.10.10.0" -w /usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt -fc 404,302 -t 50
```

### 필터링 옵션

- `-fs 178`: 응답 크기(바이트)가 178인 결과를 필터링합니다. 이는 일반적으로 "찾을 수 없음" 페이지와 같은 특정 응답을 제외하는 데 유용합니다.
- `-mc 200, 302`: 200, 302 상태만 보고 싶은 경우
- `-fc 304`: 제외

### 성능 옵션

- `-t 100`: 동시에 실행할 스레드 수를 100개로 설정합니다. 스레드 수가 많을수록 스캔 속도가 빨라지지만, 대상 서버에 부하를 줄 수 있습니다.

## 디렉토리 브루트포싱

```bash
ffuf -u http://target.com/FUZZ -w /usr/share/wordlists/seclists/Dicovery/Web-Content/common.txt
# -k : https 옵션 필수
ffuf -u https://192.168.165.180/FUZZ -w /usr/share/seclists/Discovery/Web-Content/common.txt -k
```

## TOR를 통한 익명 스캔 (선택적)

```bash
torsocks ffuf -u http://target.com/FUZZ -w /usr/share/wordlists/seclists/Dicovery/Web-Content/common.txt
```

- `torsocks`: TOR 네트워크를 통해 요청을 라우팅합니다. 이는 익명성을 제공하지만 속도가 느려질 수 있습니다.

## OSCP 시험에서 유용한 ffuf 사용 사례

### 1. 숨겨진 디렉토리/파일 탐색

```bash
ffuf -u http://target.ip/FUZZ -w /usr/share/wordlists/seclists/Dicovery/Web-Content/common.txt -e .php,.txt,.html
```

- `-e .php,.txt,.html`: 지정된 확장자를 추가하여 검색합니다.

### 2. 특정 응답 코드만 표시

```bash
ffuf -u http://target.ip/FUZZ -w /usr/share/wordlists/seclists/Dicovery/Web-Content/common.txt -mc 200,301,302
```

- `-mc 200,301,302`: 지정된 HTTP 상태 코드를 가진 응답만 표시합니다.

### 3. 파라미터 퍼징

```bash
ffuf -u http://target.ip/script.php?FUZZ=value -w /usr/share/wordlists/seclists/Dicovery/Web-Content/common.txt
```

### 4. POST 요청 퍼징

```bash
ffuf -X POST -u http://target.ip/login -d "username=admin&password=FUZZ" -w /usr/share/seclists/Passwords/Common-Credentials/10k-most-common.txt


find / -name bypass\*
/usr/share/seclists/Web-Shells/WordPress/bypass-login.php

ffuf -w bypass.txt -X POST -u http://lookup.thm/login.php -d 'username=FUZZ&password=asdf' -H "Content-Type: application/x-www-form-urlencoded; charset=UTF-8" -fw 10

```

- `-X POST`: HTTP 메소드를 POST로 지정합니다.
- `-d "username=admin&password=FUZZ"`: POST 데이터를 지정합니다.

### 5. 결과 저장

```bash
ffuf -u http://target.ip/FUZZ -w /usr/share/wordlists/seclists/Dicovery/Web-Content/common.txt -o results.json -of json
```

- `-o results.json`: 결과를 저장할 파일을 지정합니다.
- `-of json`: 출력 형식을 JSON으로 지정합니다.

## 주의사항

1. 스레드 수(-t)는 대상 서버 환경에 따라 적절히 조절해야 합니다.
2. 너무 큰 워드리스트는 시간이 오래 걸릴 수 있으므로, 시험 환경에 맞게 최적화해야 합니다.
3. 필터링 옵션(-fs, -fc, -fl 등)을 사용하여 불필요한 결과를 제거하면 효율적입니다.
4. OSCP 시험에서는 대상 서버에 과도한 부하를 주는 공격적인 스캔은 피해야 합니다.

## OSCP용 FFUF 옵션 치트시트

## FFUF 기본 개요

FFUF(Fuzz Faster U Fool)는 OSCP에서 허용되는 웹 퍼징 도구로, 웹 애플리케이션의 숨겨진 디렉토리, 파일, 파라미터 등을 찾는 데 사용됩니다.

## 주요 필터링 옵션

### `-fl [값]` - 라인 수 기준 필터링

```bash
ffuf -w 워드리스트.txt -u http://대상URL/FUZZ -fl 124
```

- 설명: 응답에 포함된 줄(라인) 수가 정확히 124개인 결과를 제외합니다.
- 사용 예: `-fl 124`는 124줄을 가진 응답은 출력하지 않습니다.
- 활용 상황: 오류 페이지나 '찾을 수 없음' 페이지가 항상 동일한 줄 수를 가질 때 유용합니다.

### `-fs [값]` - 크기 기준 필터링

```bash
ffuf -w 워드리스트.txt -u http://대상URL/FUZZ -fs 4162
```

- 설명: 응답 크기가 정확히 4162바이트인 결과를 제외합니다.
- 사용 예: `-fs 4162`는 4162바이트 크기의 응답은 출력하지 않습니다.
- 활용 상황: 기본 웹 페이지나 오류 페이지의 크기가 항상 동일할 때 이를 제외하는 데 사용합니다.

### `-fc [값]` - 상태 코드 기준 필터링

```bash
ffuf -w 워드리스트.txt -u http://대상URL/FUZZ -fc 404,403
```

- 설명: 지정된 HTTP 상태 코드를 가진 응답을 제외합니다.
- 사용 예: `-fc 404,403`은 404(찾을 수 없음)와 403(금지됨) 상태 코드를 가진 응답을 제외합니다.
- 활용 상황: 일반적인 오류 응답을 필터링하여 실제 유용한 결과만 확인할 때 사용합니다.

### `-fw [값]` - 단어 수 기준 필터링

```bash
ffuf -w 워드리스트.txt -u http://대상URL/FUZZ -fw 42
```

- 설명: 응답에 포함된 단어 수가 정확히 42개인 결과를 제외합니다.
- 사용 예: `-fw 42`는 42개 단어를 포함한 응답은 출력하지 않습니다.
- 활용 상황: 오류 페이지가 항상 동일한 단어 수를 가질 때 유용합니다.

## 매칭 옵션 (필터링의 반대)

### `-mc [값]` - 상태 코드 기준 매칭

```bash
ffuf -w 워드리스트.txt -u http://대상URL/FUZZ -mc 200,301,302
```

- 설명: 지정된 HTTP 상태 코드를 가진 응답만 표시합니다.
- 사용 예: `-mc 200,301,302`는 200(성공), 301(영구 이동), 302(임시 이동) 상태 코드를 가진 응답만 표시합니다.
- 활용 상황: 성공적인 요청이나 리디렉션만 확인하고 싶을 때 사용합니다.

### `-ml [값]` - 라인 수 기준 매칭

```bash
ffuf -w 워드리스트.txt -u http://대상URL/FUZZ -ml 10
```

- 설명: 응답에 포함된 줄 수가 정확히 10개인 결과만 표시합니다.
- 활용 상황: 특정 형태의 응답만 확인하고 싶을 때 사용합니다.

### `-ms [값]` - 크기 기준 매칭

```bash
ffuf -w 워드리스트.txt -u http://대상URL/FUZZ -ms 1024
```

- 설명: 응답 크기가 정확히 1024바이트인 결과만 표시합니다.
- 활용 상황: 특정 크기의 응답만 확인하고 싶을 때 사용합니다.

### `-mw [값]` - 단어 수 기준 매칭

```bash
ffuf -w 워드리스트.txt -u http://대상URL/FUZZ -mw 100
```

- 설명: 응답에 포함된 단어 수가 정확히 100개인 결과만 표시합니다.
- 활용 상황: 특정 형태의 응답만 확인하고 싶을 때 사용합니다.

## 출력 옵션

### `-o [파일명]` - 결과 저장

```bash
ffuf -w 워드리스트.txt -u http://대상URL/FUZZ -o results.txt
```

- 설명: 결과를 지정된 파일에 저장합니다.
- 사용 예: `-o results.txt`는 결과를 results.txt 파일에 저장합니다.

### `-of [형식]` - 출력 형식

```bash
ffuf -w 워드리스트.txt -u http://대상URL/FUZZ -o results.json -of json
```

- 설명: 출력 형식을 지정합니다 (json, ejson, html, md, csv, ecsv).
- 사용 예: `-of json`은 JSON 형식으로 결과를 저장합니다.

## 성능 옵션

### `-t [값]` - 동시 처리 스레드 수

```bash
ffuf -w 워드리스트.txt -u http://대상URL/FUZZ -t 50
```

- 설명: 동시에 처리할 스레드 수를 지정합니다.
- 사용 예: `-t 50`은 50개의 스레드를 동시에 실행합니다.
- 주의: OSCP 시험 환경에서는 대상 서버에 과부하를 주지 않도록 적절한 값(10-50)을 사용하는 것이 좋습니다.

### `-p [초]` - 요청 간 지연 시간

```bash
ffuf -w 워드리스트.txt -u http://대상URL/FUZZ -p 0.5
```

- 설명: 요청 간 지연 시간을 초 단위로 설정합니다.
- 사용 예: `-p 0.5`는 각 요청 사이에 0.5초 지연을 추가합니다.
- 활용 상황: IDS/IPS 탐지를 회피하거나 서버 부하를 줄이기 위해 사용합니다.

## 기타 유용한 옵션

### `-e [확장자]` - 확장자 추가

```bash
ffuf -w 워드리스트.txt -u http://대상URL/FUZZ -e .php,.txt,.html
```

- 설명: 워드리스트의 각 단어에 지정된 확장자를 추가하여 검색합니다.
- 사용 예: `-e .php,.txt,.html`은 각 단어에 .php, .txt, .html 확장자를 붙여서 검색합니다.

### `-r` - 리디렉션 따라가기

```bash
ffuf -w 워드리스트.txt -u http://대상URL/FUZZ -r
```

- 설명: HTTP 리디렉션을 따라갑니다.
- 활용 상황: 30x 리디렉션이 사용되는 웹사이트에서 최종 대상을 확인할 때 사용합니다.

### `-b [쿠키]` - 쿠키 설정

```bash
ffuf -w 워드리스트.txt -u http://대상URL/FUZZ -b "session=1234abcd"
```

- 설명: HTTP 요청에 쿠키를 추가합니다.
- 활용 상황: 인증이 필요한 부분을 테스트할 때 사용합니다.

## OSCP 시험 최적화 명령어 예시

### 1. 디렉토리 브루트포싱 (기본)

```bash
ffuf -w /usr/share/wordlists/seclists/Dicovery/Web-Content/common.txt -u http://대상IP/FUZZ -mc 200,301,302,403 -o directory_scan.txt
```

- 설명: 기본 디렉토리 스캔을 수행하고, 유용한 상태 코드만 필터링하여 파일로 저장합니다.

### 2. 파일 확장자 브루트포싱

```bash
ffuf -w /usr/share/wordlists/seclists/Dicovery/Web-Content/common.txt -u http://대상IP/FUZZ -e .php,.txt,.bak -mc 200 -o files_scan.txt
```

- 설명: 파일 확장자를 추가하여 스캔하고, 200 응답만 저장합니다.

### 3. 가상 호스트 디스커버리 (서브도메인) subdmain

```bash
# 80 포트가 아닌 경우 반드시 포트 명시
ffuf -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt -u http://대상IP -H "Host: FUZZ.대상도메인또는IP" -fs 4162 -o vhosts.txt
ffuf -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt -u http://10.64.133.118 -H "Host: FUZZ.10.64.133.118" -fs 4162 -o vhosts.txt
ffuf -u http://10.65.165.154/FUZZ.php -w /usr/share/wordlists/seclists/Dicovery/Web-Content/common.txt

```

- 설명: 서브도메인을 탐색하고, 기본 페이지 크기를 필터링하여 파일로 저장합니다.

### 4. 파라미터 퍼징

```bash
ffuf -w /usr/share/seclists/Discovery/Web-Content/burp-parameter-names.txt -u "http://대상IP/index.php?FUZZ=test" -fl 42 -o params.txt
```

- 설명: 가능한 GET 파라미터를 탐색하고, 특정 라인 수를 가진 응답을 필터링합니다.

### 5. 파일 인클루전 취약점 테스트

```bash
ffuf -w /usr/share/seclists/Fuzzing/LFI/LFI-gracefulsecurity-linux.txt -u "http://대상IP/page.php?file=FUZZ" -fl 124 -o lfi_results.txt
```

- 설명: LFI 취약점을 테스트하고, 특정 라인 수를 가진 응답을 필터링합니다.

## filter

-mc Match Status Code 지정된 상태 코드를 가진 응답만 표시합니다. -fc 404 -> 404 제외
-ml Match Lines 지정된 줄 수와 일치하는 응답만 표시합니다.
-ms Match Size 지정된 크기와 일치하는 응답만 표시합니다.
-mw Match Words 지정된 단어 수와 일치하는 응답만 표시합니다.

---

## ✅ `ffuf`에서 헤더 사용: 언제, 왜 중요한가?

## 📌 기본 명령어

```bash
ffuf -u http://www.smol.thm/FUZZ -w /usr/share/seclists/Discovery/DNS/namelist.txt
```

기본적으로는 URL 경로에 대한 브루트포싱이지만, 상황에 따라 헤더는 공격 성공의 핵심이 됩니다.

---

## 🎯 헤더가 중요한 대표 상황

| 상황                            | 설명                                                                | 예시                            |
| ------------------------------- | ------------------------------------------------------------------- | ------------------------------- |
| 🔐 인증 필요                    | 세션 유지 또는 토큰 인증 필요 시                                    | `Authorization`, `Cookie`       |
| 🕵️‍♀️ User-Agent 필터링            | 웹서버가 브라우저만 허용하거나 봇 차단 시                           | `User-Agent: Mozilla/5.0`       |
| 🎭 WAF 우회                     | 웹 방화벽(Web Application Firewall)이 자동화 도구 탐지 시 우회 시도 | `X-Forwarded-For`, `Referer` 등 |
| 🧪 헤더 내부 FUZZ               | URL이 아닌 헤더 안에 FUZZ가 들어갈 때                               | `-H "X-Api-Version: FUZZ"`      |
| 🔁 세션 유지                    | 로그인 후 쿠키 기반 탐색 등                                         | `Cookie: sessionid=...`         |
| 🌐 가상 호스트 탐지 (Host 헤더) | DNS 없이 서브도메인 탐지할 때. Host 헤더 조작이 유일한 방법         | `-H "Host: FUZZ.10.10.178.114"` |

---

## 🧠 핵심 요약: `Host` 헤더가 왜 중요한가?

> `http://FUZZ.10.10.178.114`와 같은 방식은 DNS 해석이 필요해서 실패 가능성이 높습니다.
> 반면 `ffuf -u http://10.10.178.114 -H "Host: FUZZ.10.10.178.114"`는
> IP로 직접 요청하면서 `Host` 헤더를 조작해 DNS 없이 가상 호스트를 탐지할 수 있습니다.

✅ CTF나 TryHackMe 실습 환경에서 자주 사용되는 기법입니다.

---

## 🛠 헤더 추가 방법 예시

```bash
ffuf -u http://target/FUZZ -w wordlist.txt \
  -H "User-Agent: Mozilla/5.0" \
  -H "Cookie: sessionid=abc123" \
  -H "Authorization: Bearer <token>"
```

헤더 안에서 FUZZ:

```bash
ffuf -u http://target/api -H "X-Version: FUZZ" -w versions.txt
```

가상 호스트 탐지:

```bash
ffuf -u http://10.10.178.114 -H "Host: FUZZ.10.10.178.114" -w namelist.txt -fs 178
```

---
