# portfwd (port forwarding)

- meterpreter의 portfwd — 세션이 뚫린 타깃을 경유해 내 로컬 포트(-l)를 내부망 서비스(-r, -L)로 연결하는 포트 포워딩 명령.
- 내부망의 DB(127.0.0.1:3306)나 내부 웹서버(127.0.0.1:80)에 직접 접근이 막혀 있고 meterpreter 세션만 확보된 상태일 때.
- meterpreter 세션 필요. portfwd add -l <로컬포트> -p <프로토콜> -r <대상> -L <대상포트>로 추가하면 localhost:<로컬포트> 접속이 세션을 타고 전달되며, portfwd list·delete로 관리한다.

## 개요

`meterpreter` 세션 안에서 포트 포워딩을 설정하는 명령이다.
내부망에 직접 접근할 수 없을 때, 세션을 통해 원격 서비스에 우회 접근한다.

## 언제 쓰나?

- 내부망의 DB(예: `127.0.0.1:3306`), 내부 웹서버(예: `127.0.0.1:80`)에 직접 접근할 수 없을 때.
- Meterpreter 세션이 이미 하나 생겼고, 그 세션은 내 컴퓨터에 있다.

## 주요 명령

| 명령 | 설명 |
|------|------|
| `portfwd add` | 포트포워딩 추가 |
| `portfwd delete` | 삭제 |
| `portfwd list` | 현재 설정 목록 |

## 사용 예시

```bash
meterpreter> portfwd add -l 8080 -p tcp -r 127.0.0.1 -L 80
```

- `-l 8080` : 내 컴퓨터의 8080 포트로 들어오는 트래픽
- `-p tcp`: 프로토콜 (tcp/udp)
- `-r 127.0.0.1`: 전달할 대상 (내부망의 호스트)
- `-L 80`: 전달될 대상 포트

## 실전 활용

```bash
# 설정 목록 확인
meterpreter> portfwd list

# 삭제
meterpreter> portfwd delete -l 8080 -p tcp -r 127.0.0.1 -L 80
```

- `localhost:8080`으로 접속하면, 대상의 `localhost:80`으로 트래픽이 전달된다.
- 여러 개를 동시에 만들 수 있다.
- 공격 경로의 일부로 사용하되, 모든 요청이 목적지로 도달한다는 점을 인지한다.
