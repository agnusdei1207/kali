# /etc/shadow 파일 구조 핵심 정리

- 패스워드 해시가 저장되는 /etc/shadow의 9필드 구조와 john·hashcat(-m 1800) 크래킹, unshadow로 passwd와 합치는 방법을 정리한 문서
- 권한 상승 과정에서 shadow 읽기에 성공했을 때(root 소유 SUID cat, look 등) 해시를 추출해 오프라인 크래킹으로 root 비밀번호를 확보하는 단계
- 기본 권한은 root만 읽을 수 있어 다른 경로로 읽어야 하고, 크래킹에는 john·hashcat과 rockyou 같은 워드리스트가 필요하다. 두 번째 필드가 *·!면 계정이 잠긴 상태다

/etc/shadow 파일은 리눅스에서 사용자 패스워드 해시가 저장되는 파일입니다.

## 파일 형식

```
root:$6$...:19855:0:99999:7:::
```

## 각 필드 설명

- 필드 1: 사용자 이름 (예: root)
- 필드 2: 비밀번호 해시 (암호화된 비번)
- 필드 3: 마지막 비번 변경 날짜 (1970년부터 경과 일수)
- 필드 4: 비번 변경 최소 기간 (일수)
- 필드 5: 비번 변경 최대 기간 (일수)
- 필드 6: 만료 전 경고 기간 (일수)
- 필드 7: 계정 비활성화 시작일
- 필드 8: 계정 만료일
- 필드 9: 예약 필드

필드 구분자는 콜론(:)입니다.

## 실용적 활용

### 패스워드 해시 크래킹

```
john --format=sha512crypt /etc/shadow
hashcat -m 1800 hash.txt /usr/share/wordlists/rockyou.txt
```

2. 계정 사용 가능 여부 확인:

   - 두 번째 필드가 빈 값이면 패스워드 없음
   - `*` 또는 `!`로 시작하면 계정 잠김

3. 권한 상승 시 유용:
   - shadow 파일 접근 가능하면 root 해시 추출 가능
unshadow 명령어로 passwd와 결합하여 크래킹 준비
   ```
   unshadow /etc/passwd /etc/shadow > hash.txt
   ```

---

패스워드 해시 관련 추가 정보는 hashcat.md 참고
